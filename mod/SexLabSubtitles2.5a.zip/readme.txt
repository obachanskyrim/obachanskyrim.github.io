======================================
SexLab Subtitles
ver. 2.5
2016.1.31
======================================

I'm afraid my expressions may be rude or hard to read.
Because I'm not so good at English. Please be patient.

--------------------------------------

This mod can display your favorite text like subtitles at the bottom
of the screen during the SexLab Framework animation,
even during the free camera mode.
But it can display only during the animation Player is related to.

The subtitle text is displayed by situation.
For example, creature, oral, anal, handjob, aggressive...
The setting is possible with the MCM menu.
The subtitle text can imported from the JSON file in [Data/SKSE/Plugins/sexlabSubtitles].
This mod includes some sample files. But they are only Japanese, sorry.
Please replace them with your own English files.

The JSON files must be named "importSet1.json","importSet2.json", "importSet3.json"
... >> ...  "importSet30.json".
It can be imported 30 files in total.

=======================
*JSON file editing method*

{
"stringList" :
{
	"import_name" : ["Subtitles set name"],
	"import_stage1" : [
	"u#Yes. I'm fine.",
	"s#You're so lovery.",
	"u#...",
	"s#...",
	"#ssend"
	],
	"import_stage2" : [
	"She called for his name. '{s}... please hug me.'",
	"{s} hugged {u} tightly.",
	"#ssend"
	],
.......

The set of subtitles text consists of five stages.
It can be max 20 lines in one stage.
It must be to put "#ssend" at the last line.

When "#s" is putted in the top of the line,
The name of the active actor can be displayed.
And "#u" can be displayed The name of the passive actor.

"{s}" and "{u}" can be putted in the middle of the line,
are the name of the actor can be displayed.

=======================
Requires:

Skyrim SexLab Framework 1.59c
	SKSE v1.7.1 OR NEWER
	FNIS v5.1.1 OR NEWER
	SkyUI v4.1 OR NEWER

=======================
Credits:

Bethesda Softworks
SKSE team
SkyUI team - creating Unofficial UI SDK
SkyUILib Team
Skyrim Sexlab Framework
